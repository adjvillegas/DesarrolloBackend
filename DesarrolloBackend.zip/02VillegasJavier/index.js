document.addEventListener("DOMContentLoaded",() => {

let input = document.createElement("inp");
let txt = document.querySelector('#text');

const [ Observable, fromEvent, throwError, of ] = rxjs;
const [ filter, map, mergeMap ] = rxjs.operators;

});