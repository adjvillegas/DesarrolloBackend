"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.suma = void 0;
function suma(a, b) {
    return a + b;
}
exports.suma = suma;
;
