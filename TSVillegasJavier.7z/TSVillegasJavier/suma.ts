export function suma(a:number, b:number){
    return a+b;
};