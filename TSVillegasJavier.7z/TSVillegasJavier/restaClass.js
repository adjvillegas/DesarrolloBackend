"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Resta {
    constructor(a, b) {
        this.calculado = 0;
        this.calculado = a - b;
    }
    ;
    resultado() {
        return this.calculado;
    }
    ;
}
exports.default = Resta;
;
